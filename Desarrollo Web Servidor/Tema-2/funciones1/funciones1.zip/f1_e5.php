<?php

function semisuma($num1, $num2) {
    $resultado = ($num1 + $num2) / 2;
    echo "Semisuma de $num1 y $num2: $resultado<br>";
}

semisuma(10, 20);

?>
