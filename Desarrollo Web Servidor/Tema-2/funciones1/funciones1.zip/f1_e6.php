<?php

function textoEnNegrita($texto) {
    $resultado = "<b>$texto</b>";
    echo "Texto en negrita: $resultado<br>";
}

textoEnNegrita("Hola, mundo!");

?>
